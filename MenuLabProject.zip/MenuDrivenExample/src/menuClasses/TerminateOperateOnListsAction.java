package menuClasses;

public class TerminateOperateOnListsAction implements Action {

	@Override
	public void execute(Object args) {
		// TODO Auto-generated method stub

	}

}
